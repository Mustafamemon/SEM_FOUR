
echo
read -p "Enter the name " name 
read -p "Enter the batch " batch 
read -p "Enter the id " id1
echo
