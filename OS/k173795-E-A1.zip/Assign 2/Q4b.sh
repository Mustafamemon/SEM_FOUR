echo
echo $1 $2
echo "Addition : "$(( $1+$2 ))
echo "Subraction : "$(( $1-$2 ))
echo "Multiplication : "$(( $1*$2 ))
echo "Division : "$(( $1/$2 ))
echo
