sudo apt-get install gcc
sudo apt-get install build-essential
sudo apt-get install tree
sudo apt-get install python
sudo apt-get install update
sudo apt-get install mysql-server
sudo apt-get install upgrade
